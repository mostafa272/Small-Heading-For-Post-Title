=== Small Heading For Posts Title ===
Contributors: Mostafa Shahiri
Donate link: https://github.com/mostafa272/Small-Heading-For-Post-Title
Tags: heading, title, post, slug, page
Requires at least: 3.6.1
Tested up to: 4.9.x
Stable tag: 3.4.0

The Small Heading For Post Title is a simple plugin for displaying small headings before or after post title.

== Description ==
The Small Heading For Post Title is a simple plugin for displaying small headings before or after post title. It is a useful plugin for the websites
such as news websites that display some small headlines or captions before or after the main title. This plugin adds a metabox to your page/post forms
in admin panel and you can set a custom text and position of the text and It is shown before or after the post title based on your choice.

Also, in settings page of this plugin, you can add some CSS codes for styling the small headings and you can determine and control that small headings
are shown in which sections of Wordpress.


== Installation ==

Upload this plugin to your blog, Activate it.Then go to settings page of the plugin and set its options.

== Screenshots ==

1. Settings
2. Meta box
3. Output

== Changelog ==

= 1.0 =
First release
